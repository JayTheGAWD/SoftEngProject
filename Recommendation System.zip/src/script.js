const message = 'Recommendation' //Show  recommendation on UI
const Result = (`Recommendations for ${userId}:`, recommendations); 
// Update header text
document.querySelector('#header').innerHTML = message

//Goal is to compare what user 1 and 2 picked and recommend a game that user 1 hasnt played
// Store the user choice of games
const userItemData = {
  user1: { game1: 5, game2: 4, game3: 3 },
  user2: { game1: 4, game2: 5, game4: 2 },
  //Saves different users and then compares how often they selected one of the games(game files)
};

// Function to calculate recommendations using collaborative filtering
function getRecommendations(userId) {
  const userRatings = userItemData[userId] || {};

  
  const recommendations = {};
  for (const user in userItemData) {
    if (user !== userId) {
      for (const game in userItemData[user]) {
        if (!userRatings[game]) {
          recommendations[game] = (recommendations[game] || 0) + userItemData[user][game];
        }
      }
    }
  }
  //Figure out how to assign u
const userPreferences = {
  userId1: { liked: [1, 2], disliked: [] },
  // Add more user preferences
};
  // Sort and return recommendations
  const sortedRecommendations = Object.keys(recommendations).sort((a, b) => recommendations[b] - recommendations[a]);
  return sortedRecommendations;
}
//Try to recommending based on genre NOT WORKING
const games = [
  { id: 1, title: 'Game1', genre: ['Action'] },
  { id: 2, title: 'Game2', genre: ['Action'] },
  { id: 3, title: 'Game3', genre: ['Mystery'] },
  { id: 4, title: 'Game4', genre: ['Adventure'] },
  // Add in games, change names to what games we actually have
];
// Hard coded check to see if it works
const userId = 'user1';
// const userId = 'user2'; Need to make it work for different users
const recommendations = getRecommendations(userId);
console.log(`Recommendations for ${userId}:`, recommendations); 
//shows on console need to show on frontend ask team leader
//Recommends based on what game user 1 didnt select yet when changed to user2 it should be game 3
// Log to console
console.log(message)